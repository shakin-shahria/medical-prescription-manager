package com.example.prescription;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrescriptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
